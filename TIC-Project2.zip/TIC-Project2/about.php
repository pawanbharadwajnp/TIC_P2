<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>ABOUT US</title>
    <link rel="stylesheet" href="styles.css"/>
  </head>
  <body>
  <button align="right"><a href="index.php">back</a></button>

<h1>ABOUT US</h1>
<center>

<p><b>SMP is a company, established under a mission of service to humanity, we provide a
wide range of pharmaceuticals and we are building a reputation of quality and integrity known
around the world.
</b>  <p>
  <br>
  <br>
  <p><b>The products that we supply at SMP Meets the best safety and quality standards. We are being
audited regularly by officials to ensure that the highest safety and quality criteria were met.
</b></p>

    <p><b>“In every crisis, doubt or confusion, take the higher path - the path of compassion, courage, understanding and love.”</b></p>
    <div class="">
      <h2>OUR VISION</h2>
      <img class="vision" src="https://image.flaticon.com/icons/png/128/1933/1933935.png" alt="">
      <p>MAKE THINGS EASY IN THESE TOUGH SITUATIONS</p>
<br>
<h2>OUR MISSION</h2>
<img class="vision"src="https://media.savetherhino.org/prod/uploads/2018/04/our-mission.jpg" alt="">
<p>TO BE A LEADING DEALERS IN MEDICAL EQUIPMENTS</p>
<br>

<h2>CONTACT US ON </h2>
<br>
<p><b>whatsapp</b></p>

<br><a href="https://play.google.com/store/apps/details?id=com.whatsapp&hl=en_IN&gl=US"><img class="whats" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQSxJ0k7wUnMNYVUAJ1mS9Inw3SxbybJyyA1Q&usqp=CAU" alt="whatsapp us"></a>

<p><b>7655465436</b></p>
  </center>

  </body>
</html>
