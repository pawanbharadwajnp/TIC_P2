<?php
error_reporting();
include('config.php');
session_start();
$_SESSION;
$id=$_GET['id'];

	include("../login/connection.php");
	require("../login/functions.php");


$sql ="DELETE FROM `tblcontactdata` WHERE id = :id";
$query = $dbh -> prepare($sql);
$query->bindParam(':id',$id,PDO::PARAM_STR);


$query->execute();

echo "<script>alert('Your info deleted successfully.');</script>";
  echo "<script>window.location.href='../admin/controls.php'</script>";